"use strict";
require("dotenv").config();
require("dotenv-flow").config({
  path: "./env/",
});
const express = require("express");
const app = express();
const helmet = require("helmet");
const cors = require("cors");
const connectionDb = require("./app/config/db_connection");
const path = require("path");

const IP = process.env.IP;
const PORT = process.env.PORT || 3000;

app.use(cors());

app.use(helmet());
app.use(express.urlencoded({ extended: true, limit: "7mb" }));

app.use(express.json());

require("./app/routes")(app);
const onServerStart = () => {
  const ENVIROINMENT = process.env.NODE_ENV || "development";
  const message = `Server Listening On Process ${process.pid}, Port, ${PORT}, ENVIROINMENT=${ENVIROINMENT}`;
  connectionDb();
  console.log(message);
};

const server = app.listen(PORT, IP, onServerStart);
