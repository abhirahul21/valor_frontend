"use strict";

const express = require("express");
const router = express.Router();
const UserController = require("../controllers/user.controller");

const { authorize } = require("../helpers/authorise-filter");

router.route("/").post(authorize(), new UserController().Create()).get(authorize(), new UserController().GetAll()).delete(authorize(), new UserController().DeleteAll());

router.route("/:id").put(authorize(), new UserController().Update()).get(authorize(), new UserController().Get()).delete(authorize(), new UserController().Delete());

router.route("/:id/resetpassword").post(authorize(), new UserController().ResetPassword());

router.route("/login").post(new UserController().Login());
// router.route("/logout").post(authorize(), new UserController().Logout());
router.route("/userProfile").post(authorize(), new UserController().GetUserProfile());
router.route("/resetPass").post(authorize(), new UserController().ResetPassword());
//forgotpassword

module.exports = router;
