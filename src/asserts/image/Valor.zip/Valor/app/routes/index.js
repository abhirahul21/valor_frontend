const { errorHandlingMiddleware } = require("../helpers/Error-handling");
const { requestLogger } = require("../helpers/Request-handling");

module.exports = (app) => {
  //   app.use(requestLogger);
  app.use("/api/v1/users", require("./user.route"));

  app.use(errorHandlingMiddleware);
};
