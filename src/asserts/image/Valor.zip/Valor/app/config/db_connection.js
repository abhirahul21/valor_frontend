"use strict";
const mongoose = require("mongoose");

async function connectionDb() {
  try {
    let db = await mongoose.connect(process.env.MONGO_DB_URL, { useNewUrlParser: true, useUnifiedTopology: true });
    console.log("Succesfully Connected to DB");
  } catch (error) {
    console.log("Database Connection Failed", error);
    process.exit(1);
  }
}

module.exports = connectionDb;
