const { logger } = require("../logger/system-logger");

async function errorHandlingMiddleware(error, req, res, next) {
  if (error.name === "ValidationError") {
    const keys = Object.keys(error.errors);
    const errorMessages = keys
      .map((key) => error.errors[key].message)
      .filter((message) => message)
      .toString();
    error.message = errorMessages;
    error.status = 400;
  }

  if (req.headers.authorization) {
    let token = req.headers.authorization.split(" ")[1];
  }
  if (error.name === "MongoError" && error.code === 11000) {
    error.status = 409;
  }

  const { message = "Something Went Wrong" } = error;
  if (error) {
    const logs = {
      message: error.message,
      status: "error",
      platform: req.headers["platform"],
      userIp: req.headers["x-forwarded-for"] || req.connection.remoteAddress,
      method: req.method,
      userAgent: req.headers["user-agent"],
      url: req.originalUrl,
    };
    // task({ type: 'error', message: logs })
    logger.log({
      level: "error",
      message: logs,
    });
  }
  res.status(error.status).json({ message });
}

module.exports = {
  errorHandlingMiddleware,
};
