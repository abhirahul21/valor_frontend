"use strict";

const jwt = require("jsonwebtoken");
const jwtSecret = process.env.JWT_SECRET;
const tokenExpirePeriod = process.env.JWT_TOKENEXPIRE;

async function generate(payLoad, expiry) {
  payLoad.expiresIn = expiry || tokenExpirePeriod;
  const expiresIn = expiry || tokenExpirePeriod;
  const isObject = typeof payLoad === "object";

  if (!payLoad) {
    const error = new TypeError("Token Payload Should Not Be Empty");
    throw error;
  }

  if (!expiry) {
    const error = new TypeError("Token expiry Should Not Be Empty");
    throw error;
  }

  if (!isObject) {
    const error = new TypeError("Token Payload Must Be An Object");
    throw error;
  }

  return new Promise((resolve, reject) => {
    jwt.sign(payLoad, jwtSecret, { expiresIn }, (error, token) => {
      if (error) {
        reject(error);
      } else {
        resolve(token);
      }
    });
  });
}

async function verifyToken(token) {
  if (!token) {
    const error = new TypeError("Token Should Not Be Empty");
    error.status = 401;
    throw error;
  }

  return new Promise((resolve, reject) => {
    jwt.verify(token, jwtSecret, (error, decodedToken) => {
      if (error) {
        error = new TypeError("Invalid Token!");
        error.status = 401;
        reject(error);
      } else {
        resolve(decodedToken);
      }
    });
  });
}

module.exports = {
  generate: generate,
  verify: verifyToken,
};
