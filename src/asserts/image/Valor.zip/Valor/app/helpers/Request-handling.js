const { logger } = require("../logger/system-logger");

async function requestLogger(req, res, next) {
  let logs = {
    platform: req.headers["platform"],
    userIp: req.headers["x-forwarded-for"] || req.connection.remoteAddress,
    method: req.method,
    userAgent: req.headers["user-agent"],
    url: req.originalUrl,
    origin: req.headers.origin,
  };
  logger.log({
    level: "error",
    message: logs,
  });
  next();
}

module.exports = {
  requestLogger,
};
