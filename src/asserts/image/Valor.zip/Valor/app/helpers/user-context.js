function UserContext(req) {
  const userContext = {};
  userContext.ip =
    req.headers["x-forwarded-for"] || req.connection.remoteAddress || req.socket.remoteAddress || (req.connection.socket ? req.connection.socket.remoteAddress : null);
  userContext.locale = req.headers["accept-language"] || "en";
  userContext.userId = req.tokenData && req.tokenData.userId ? req.tokenData.userId : "NA";
  return userContext;
}

module.exports = UserContext;
