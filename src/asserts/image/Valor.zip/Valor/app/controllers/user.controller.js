const { BaseService } = require("../services/base.service");
const { UserSchema } = require("../models/user.schema");
const { AddressSchema } = require("../models/address.schema");
const { ContactSchema } = require("../models/contact.schema");
const { hash } = require("../helpers/password-helper");
const mongoose = require("mongoose");
const BaseResponse = require("../helpers/response_builder");
const UserContext = require("../helpers/user-context");
const { generate } = require("../helpers/Jwt");
class UserController {
  Create() {
    return async (req, res, next) => {
      try {
        const userContext = new UserContext(req);
        req.body.password = await hash(req.body.password);
        const response = await new BaseService(UserSchema, userContext).create(req.body);
        if (req.body.address) {
          const address = req.body.address;
          address.parent = "User";
          address.parentId = response._id;
          response.address = await new BaseService(AddressSchema).create(address);
        }

        if (req.body.contact) {
          const contact = req.body.contact;
          contact.parent = "User";
          contact.parentId = response._id;
          response.contact = await new BaseService(ContactSchema).create(contact);
        }
        res.status(200).json(BaseResponse(true, 200, "User created successfully", response));
      } catch (error) {
        res.status(400).json(BaseResponse(false, 400, "User created failed", error.message));
      }
    };
  }

  Update() {
    return async (req, res, next) => {
      try {
        const userContext = new UserContext(req);
        const response = await new BaseService(UserSchema).findByIdAndUpdate(req.params.id, req.body, {});
        if (req.body.address) {
          const address = req.body.address;
          address.parent = "User";
          address.parentId = response._id;

          const orinigalAddress = await new BaseService(AddressSchema).findOne({
            parent: "User",
            parentId: response._id,
          });
          if (orinigalAddress) {
            response.address = await new BaseService(AddressSchema).findByIdAndUpdate(orinigalAddress._id, address, {});
          } else {
            response.address = await new BaseService(AddressSchema).create(address);
          }
        }
        if (req.body.contact) {
          const contact = req.body.contact;
          contact.parent = "User";
          contact.parentId = response._id;
          const orinigalContact = await new BaseService(ContactSchema).findOne({
            parent: "User",
            parentId: response._id,
          });

          if (orinigalContact) {
            response.contact = await new BaseService(ContactSchema).findByIdAndUpdate(orinigalContact._id, contact, {});
          } else {
            response.contact = await new BaseService(ContactSchema).create(contact);
          }
        }
        res.status(200).json(BaseResponse(true, 200, "User Updated successfully", response));
      } catch (error) {
        res.status(400).json(BaseResponse(false, 400, "User Update failed", error.message));
      }
    };
  }

  GetAll() {
    return async (req, res, next) => {
      try {
        const userContext = new UserContext(req);
        const response = await new BaseService(UserSchema).find({});
        res.status(200).json(BaseResponse(true, 200, "Users fetched successfully", response));
      } catch (error) {
        res.status(400).json(BaseResponse(false, 400, "User fetched failed", error.message));
      }
    };
  }

  DeleteAll() {
    return async (req, res, next) => {
      try {
        const userContext = new UserContext(req);
        const response = await new BaseService(UserSchema).deleteMany({}, {});
        res.status(200).json(BaseResponse(true, 200, "Users deleted successfully", response));
      } catch (error) {
        res.status(400).json(BaseResponse(false, 400, "User delete all failed", error.message));
      }
    };
  }

  Get() {
    return async (req, res, next) => {
      try {
        const userContext = new UserContext(req);
        const response = await new BaseService(UserSchema).findById({
          _id: req.params.id,
        });
        const address = await new BaseService(AddressSchema).findOne({
          parent: "User",
          parentId: response._id,
        });
        const contact = await new BaseService(ContactSchema).findOne({
          parent: "User",
          parentId: response._id,
        });

        const finalObject = Object.assign({}, response._doc);

        if (address) {
          finalObject.address = Object.assign({}, address._doc);
        }
        if (contact) {
          finalObject.contact = Object.assign({}, contact._doc);
        }

        res.status(200).json(BaseResponse(true, 200, "User fetched successfully", finalObject));
      } catch (error) {
        res.status(400).json(BaseResponse(false, 400, "User fetch failed", error.message));
      }
    };
  }

  Delete() {
    return async (req, res, next) => {
      try {
        const userContext = new UserContext(req);
        const response = await new BaseService(UserSchema).findByIdAndDelete({ _id: req.params.id }, {});
        res.status(200).json(BaseResponse(true, 200, "User deleted successfully", response));
      } catch (error) {
        res.status(400).json(BaseResponse(false, 400, "User delete failed", error.message));
      }
    };
  }
  Login() {
    return async (req, res, next) => {
      try {
        let user = await new BaseService(UserSchema).findOne({ email: new RegExp(`^${req.body.email}$`, "i") }, { lean: true });

        if (!user) {
          return res.status(200).json(BaseResponse(false, 400, "Invalid username or password", null));
        }
        const checkPassword = await match(req.body.password, user.password);
        if (!checkPassword) {
          return res.status(200).json(BaseResponse(false, 400, "Invalid username or password", null));
        }
        const token = await generate(
          {
            userId: user._id,
          },
          60 * 60 * 60
        );
        res.status(200).json(BaseResponse(true, 200, "Success", { token }));
      } catch (error) {
        res.status(200).json(BaseResponse(false, 400, error.message, null));
      }
    };
  }
  GetUserProfile() {
    return async (req, res, next) => {
      try {
        const result = await new BaseService(UserSchema).findOne(
          { _id: req.tokenData.userId },
          {
            lean: true,
            populate: "-password",
          }
        );
        delete result.password;
        result.address = await new BaseService(AddressSchema).findOne({ parent: "User", parentId: result._id });
        result.contact = await new BaseService(ContactSchema).findOne({ parent: "User", parentId: result._id });

        res.status(200).json({ success: true, status: 200, message: "Success", data: result });
      } catch (error) {
        res.status(200).json(BaseResponse(false, 400, error.message, null));
      }
    };
  }

  ResetPassword() {
    return async (req, res, next) => {
      try {
        const decodedData = await verify(req.body.token);
        const user = await new BaseService(UserTokenSchema).findOne({ token: req.body.token });
        if (!user) {
          return res.status(200).json(BaseResponse(false, 400, "Invalid User", null));
        }
        const checkUser = await new BaseService(UserSchema).findOne({ _id: user.userId });
        if (checkUser.locked) {
          return res.status(200).json(BaseResponse(false, 400, "Account got locked", null));
        }
        const password = await hash(req.body.password);
        await new BaseService(UserSchema).findOneAndUpdate(
          {
            _id: user.userId,
          },
          {
            password: password,
            accepted: true,
            isPasswordConfirm: true,
          },
          {
            options: {
              new: true,
            },
          }
        );

        res.json({
          status: 200,
          success: true,
          message: "Successfully Password Got Reseted!",
        });
      } catch (error) {
        res.status(200).json(BaseResponse(false, 400, error.message, null));
      }
    };
  }

  Logout() {
    return async (req, res, next) => {
      try {
        const userContext = new UserContext(req);
        const token = (req.headers.authorization || req.headers.Authorization || "").split("Bearer ").pop();
        const response = await new BaseService(UserTokenSchema).findOneAndDelete({ token: token }, {});
        res.status(200).json(BaseResponse(true, 200, "Logout successfully", response));
      } catch (error) {
        res.status(400).json(BaseResponse(false, 400, "Logout failed", error.message));
      }
    };
  }
}
module.exports = UserController;
