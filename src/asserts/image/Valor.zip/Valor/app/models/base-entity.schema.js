const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const BaseSchema = require("./base.schema");
const { BaseService } = require("../services/base.service");
// const { AuditSchema } = require("./audit.schema");
function BaseEntitySchema(schemaName, definition, options, index) {
  return mongoose.model(schemaName, getSchema(), schemaName);

  function getSchema() {
    const schema = new mongoose.Schema(Object.assign({}, BaseSchema, definition), options)
      .post("save", (doc, next) => {
        createAudit(doc, "CREATE", schemaName);
        next();
      })
      .pre("findOneAndUpdate", function (next) {
        this.update({}, { $inc: { __v: 1 } }, next);
      })
      .post("findOneAndUpdate", (doc, next) => {
        createAudit(doc, "UPDATE", schemaName);
        next();
      })
      .post("findOneAndDelete", (doc, next) => {
        createAudit(doc, "DELETE", schemaName);
        next();
      })
      .post("findIdAndDelete", (doc, next) => {
        createAudit(doc, "DELETE", schemaName);
        next();
      });

    if (index) {
      schema.index(index, { unique: true });
    }
    return schema;
  }
}

// function createAudit(doc, type, schemaName) {
//   try {
//     const data = {
//       schemaName,
//       refId: doc._id,
//       operation: type,
//       version: doc.__v,
//       oldValue: JSON.stringify(doc),
//       newValue: JSON.stringify(doc),
//       applicationId: doc.applicationId,
//       companyId: doc.applicationId,
//     };

//     data.createdBy = doc.createdBy;
//     data.lastModifiedBy = doc.lastModifiedBy;
//     if (type === "CREATE") {
//       data.oldValue = "";
//     }
//     if (type === "DELETE") {
//       data.newValue = "";
//     }
//     new BaseService(AuditSchema).create(data);
//     return;
//   } catch (error) {
//     // console.log(error);
//   }
// }

module.exports = BaseEntitySchema;
