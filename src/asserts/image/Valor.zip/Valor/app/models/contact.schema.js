const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const BaseEntitySchema = require("./base-entity.schema");
const ContactSchema = BaseEntitySchema(
  "Contact",
  {
    faxNumber: { type: String },
    website: { type: String },
    email: { type: String },
    mobileNumber: { type: String },
    phone: { type: String },
    parent: { type: String },
    parentId: { type: Schema.Types.ObjectId, ref: "User", required: true },
  },
  {
    timestamps: true,
  }
);
module.exports = { ContactSchema };
