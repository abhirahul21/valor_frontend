const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const BaseEntitySchema = require("./base-entity.schema");

const AddressSchema = BaseEntitySchema(
  "Address",
  {
    address1: { type: String },
    address2: { type: String },
    city: { type: String },
    country: { type: String },
    state: { type: String },
    zipCode: { type: String },
    region: { type: String },
    locality: { type: String },
    landmark: { type: String },
    continent: { type: String },
    longitudeLatitude: { type: String },
    parent: { type: String },
    parentId: { type: Schema.Types.ObjectId, ref: "User", required: true },
  },
  {
    timestamps: true,
  }
);
module.exports = { AddressSchema };
