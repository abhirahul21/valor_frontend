const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const BaseEntitySchema = require("./base-entity.schema");
const baseSchema = require("./base.schema");

const AuditSchema = BaseEntitySchema(
  "Audit",
  {
    userId: { type: Schema.Types.ObjectId, ref: "User" },
    schemaName: { type: String, required: true },
    oldValue: { type: String },
    refId: { type: String, required: true },
    newValue: { type: String },
    operation: { type: String, required: true, enum: ["UPDATE", "CREATE", "DELETE"] },
    version: { type: Number, required: true },
    ...baseSchema,
  },
  {
    timestamps: true,
  }
);
module.exports = { AuditSchema };
