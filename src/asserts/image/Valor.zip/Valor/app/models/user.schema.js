const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const BaseEntitySchema = require("./base-entity.schema");

const UserSchema = BaseEntitySchema(
  "User",
  {
    firstName: { type: String, required: true, intl: true },
    lastName: { type: String, intl: true },
    userName: { type: String, unique: true },
    email: { type: String, required: true, unique: true },
    password: { type: String },
    lastLoginAt: { type: Date },
    phone: { type: String },
  },
  {
    timestamps: true,
    toJSON: {
      virtuals: true,
    },
  },
  { email: 1, userName: 1 }
);
module.exports = { UserSchema };
